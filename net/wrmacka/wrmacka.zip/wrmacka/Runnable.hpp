#pragma once

class Runnable {

public:
    virtual ~Runnable() {};
    virtual void run() = 0;
};