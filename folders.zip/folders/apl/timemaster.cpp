//=============================================================================
// Project      <<TEST>>
//
// Copyright <2018> MBel
//
//=============================================================================
/// @file        <timemaster.cpp>
/// @ingroup     <apl>
/// @brief       <controle time>

#include"timemaster.hpp"

namespace apl
{


//========================================
/// @brief     <purpose>
/// @param     [IN]  <input parameter + ranges>
/// @param     [OUT] <output parameter + ranges>
/// @return    <return value description>
//========================================
int Timemaster::init()
{
          //Interface 

return 0;
} //Timemaster::init()


} //namespace apl


