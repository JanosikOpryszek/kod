//=============================================================================
// Project      <<TEST>>
//
// Copyright <2018> MBel
//
//=============================================================================
/// @file        <router.cpp>
/// @ingroup     <service>
/// @brief       <manage msg>

#include"router.hpp"

namespace service
{

//========================================
/// @brief     <purpose>
/// @param     [IN]  <input parameter + ranges>
/// @param     [OUT] <output parameter + ranges>
/// @return    <return value description>
//========================================
void Router::metoda()
{

return;
} //Router::metoda()

} //namespace service

