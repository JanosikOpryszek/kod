//=============================================================================
// Project      <<TEST>>
//
// Copyright <2018> MBel
//
//=============================================================================
/// @file        <router.hpp>
/// @ingroup     <service>
/// @brief       <manage msg>


#ifndef ROUTER_HPP
#define ROUTER_HPP

#include<iostream>

namespace service
{

class Router
{
public:
void metoda();

};    //class prototypes

}     //namespace service

#endif //ROUTER_HPP

 
