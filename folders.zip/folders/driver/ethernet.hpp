//=============================================================================
// Project      <<TEST>>
//
// Copyright <2018> MBel
//
//=============================================================================
/// @file        <ethernet.hpp>
/// @ingroup     <driver>
/// @brief       <network driver>


#ifndef ETHERNET_HPP
#define ETHERNET_HPP

#include<iostream>

namespace driver
{

class Ethernet
{
public:
void metoda();



};    //class prototypes

}     //namespace driver

#endif //ETHERNET_HPP


 
