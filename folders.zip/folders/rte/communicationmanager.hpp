//=============================================================================
// Project      <<TEST>>
//
// Copyright <2018> MBel
//
//=============================================================================
/// @file        <communicationmanager.hpp>
/// @ingroup     <rte>
/// @brief       <real time environment>


#ifndef COMMUNICATIONMANAGER_HPP
#define COMMUNICATIONMANAGER_HPP 

#include<iostream>

namespace rte
{

class Communicationmanager 
{
public:
void metoda();

};    //class prototypes

}     //namespace rte

#endif //COMMUNICATIONMANAGER_HPP 
 
