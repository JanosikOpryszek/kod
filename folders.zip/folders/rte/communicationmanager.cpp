//=============================================================================
// Project      <<TEST>>
//
// Copyright <2018> MBel
//
//=============================================================================
/// @file        <communicationmanager.cpp>
/// @ingroup     <rte>
/// @brief       <real time environment>

#include"communicationmanager.hpp"

namespace rte
{

//========================================
/// @brief     <purpose>
/// @param     [IN]  <input parameter + ranges>
/// @param     [OUT] <output parameter + ranges>
/// @return    <return value description>
//========================================
void Communicationmanager::metoda()
{

return;
} //Communicationmanager::metoda()

} //namespace rte


 
